package view;

/** 
 * Represents the CAMS header to be printed
 * @author Jared Pek
 */
public class Header {
    /** The header view to be printed */
    public static void main() {
        System.out.println("===========================================================");
        System.out.println("|                     Welcome to CAMS                     |");
        System.out.println("===========================================================");
    }
}
